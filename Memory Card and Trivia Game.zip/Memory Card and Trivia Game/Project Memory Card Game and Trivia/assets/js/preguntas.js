let preguntas = [

    {
        num: 1,
        pregunta: "¿Cuál es el hueso más grande del cuerpo humano?",
        respuesta: "C- Fémur",
        opciones: [
            "A- Peroné",
            "B- Húmero",
            "C- Fémur",
            "D- Tibia"
        ]
    },
    {
        num: 2,
        pregunta: "¿Cuál es el planeta más grande del sistema solar?",
        respuesta: "B- Júpiter",
        opciones: [
            "A- Marte",
            "B- Júpiter",
            "C- Tierra",
            "D- Venus"
        ]
    },
    {
        num: 3,
        pregunta: "¿Cuál es el océano más grande del mundo?",
        respuesta: "C- Pacífico",
        opciones: [
            "A- Atlántico",
            "B- Índico",
            "C- Pacífico",
            "D- Ártico"
        ]
    },
    {
        pregunta: "¿Quién es el famoso Rey de Rock en los Estados Unidos?",
        respuesta: "A- Elvis Presley",
        opciones: [
            "A- Elvis Presley",
            "B- Chuck Berry",
            "C- Buddy Holly",
            "D- Little Richard"
        ]
    },
    {
        num: 5,
        pregunta: "¿Cuál es el país más grande del mundo?",
        respuesta: "D- Rusia",
        opciones: [
            "A- China",
            "B- Estados Unidos",
            "C- Canadá",
            "D- Rusia"
        ]
    },
    {
        num: 6,
        pregunta: "¿En qué lugar del cuerpo se produce la insulina?",
        respuesta: "C- Páncreas",
        opciones: [
            "A- Hígado",
            "B- Riñones",
            "C- Páncreas",
            "D- Estómago"
        ]
    },
    {
        num: 7,
        pregunta: "¿Cómo se llama el animal más rápido del mundo?",
        respuesta: "B- Guepardo",
        opciones: [
            "A- León",
            "B- Guepardo",
            "C- Halcón peregrino",
            "D- Antílope"
        ]
    },
    {
        num: 8,
        pregunta: "¿Cuál fue el primer metal que empleó el hombre?",
        respuesta: "A- Cobre",
        opciones: [
            "A- Cobre",
            "B- Hierro",
            "C- Oro",
            "D- Plata"
        ]
    },
    {
        num: 9,
        pregunta: "¿Cuál es el único mamífero capaz de volar?",
        respuesta: "C- Murciélago",
        opciones: [
            "A- Águila",
            "B- Colibrí",
            "C- Murciélago",
            "D- Pato"
        ]
    },
    {
        num: 10,
        pregunta: "¿Cuál es el libro sagrado del Islam?",
        respuesta: "A- Corán",
        opciones: [
            "A- Corán",
            "B- Biblia",
            "C- Torá",
            "D- Vedas"
        ]
    },
    {
        num: 11,
        pregunta: "¿Qué país es conocido como la 'tierra del sol naciente'?",
        respuesta: "C- Japón",
        opciones: [
            "A- Corea del Sur",
            "B- China",
            "C- Japón",
            "D- Tailandia"
        ]
    },
    {
        num: 12,
        pregunta: "¿De qué país es originario el café?",
        respuesta: "A- Etiopía",
        opciones: [
            "A- Etiopía",
            "B- Brasil",
            "C- Colombia",
            "D- Vietnam"
        ]
    },
    {
        num: 13,
        pregunta: "¿Cuántos corazones tienen los pulpos?",
        respuesta: "C- 3",
        opciones: [
            "A- 1",
            "B- 2",
            "C- 3",
            "D- 4"
        ]
    },
    {
        num: 14,
        pregunta: "¿Cómo se llama el proceso por el cual las plantas obtienen alimento?",
        respuesta: "B- Fotosíntesis",
        opciones: [
            "A- Germinación",
            "B- Fotosíntesis",
            "C- Polinización",
            "D- Fermentación"
        ]
    },
    {
        num: 15,
        pregunta: "¿De qué lengua proviene el español?",
        respuesta: "D- Latín",
        opciones: [
            "A- Griego",
            "B- Árabe",
            "C- Hebreo",
            "D- Latín"
        ]
    },
    {
        num: 16,
        pregunta: "¿En qué continente está Egipto?",
        respuesta: "B- África",
        opciones: [
            "A- Asia",
            "B- África",
            "C- Europa",
            "D- América"
        ]
    },
    {
        num: 17,
        pregunta: "¿Quién pintó 'La Última Cena'?",
        respuesta: "A- Leonardo da Vinci",
        opciones: [
            "A- Leonardo da Vinci",
            "B- Michelangelo",
            "C- Rafael",
            "D- Caravaggio"
        ]
    },
    {
        num: 18,
        pregunta: "¿Quién es el autor de El Quijote?",
        respuesta: "C- Miguel de Cervantes",
        opciones: [
            "A- William Shakespeare",
            "B- Federico García Lorca",
            "C- Miguel de Cervantes",
            "D- Lope de Vega"
        ]
    },
    {
        num: 19,
        pregunta: "¿Qué cantidad de huesos hay en el cuerpo humano adulto?",
        respuesta: "B- 206",
        opciones: [
            "A- 201",
            "B- 206",
            "C- 210",
            "D- 190"
        ]
    },
    {
        num: 20,
        pregunta: "¿Cuál es el símbolo químico del oro?",
        respuesta: "C- Au",
        opciones: [
            "A- Go",
            "B- Ag",
            "C- Au",
            "D- Gd"
        ]
    }
]
